package bkLoan;

public class CarLoan extends LoanManager {

    private String carModel;

    public CarLoan(String loanId, double amount, double rate, int duration,
                   String officer, String branch, String carModel) {

        super(loanId, "Car", amount, rate, duration, "Pending", officer, branch);
        this.carModel = carModel;
    }

    @Override
    public boolean checkEligibility(double income, int creditScore) {
        return income > 500 && creditScore >= 600;
    }

    @Override
    public double calculateInterest() {
        return super.calculateInterest() * 1.02;
    }

    @Override
    public String generateLoanReport() {
        return super.generateLoanReport() + "\nCar Model: " + carModel;
    }

    @Override
    public String toString() {
        return super.toString() + "\nCar Model: " + carModel;
    }
}
