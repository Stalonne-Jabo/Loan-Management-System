package bkLoan;

public class BusinessLoan extends LoanManager {

    private String businessName;

    public BusinessLoan(String loanId, double amount, double rate, int duration,
                        String officer, String branch, String businessName) {

        super(loanId, "Business", amount, rate, duration, "Pending", officer, branch);
        this.businessName = businessName;
    }

    @Override
    public boolean checkEligibility(double income, int creditScore) {
        return income > 1000 && creditScore >= 700;
    }

    @Override
    public double calculateInterest() {
        return super.calculateInterest() * 1.1;
    }

    @Override
    public String generateLoanReport() {
        return super.generateLoanReport() + "\nBusiness Name: " + businessName;
    }

    @Override
    public String toString() {
        return super.toString() + "\nBusiness Name: " + businessName;
    }
}

