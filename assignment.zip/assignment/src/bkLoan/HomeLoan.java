package bkLoan;

public class HomeLoan extends LoanManager {

    private double propertyValue;

    public HomeLoan(String loanId, double amount, double rate, int duration,
                    String officer, String branch, double propertyValue) {

        super(loanId, "Home", amount, rate, duration, "Pending", officer, branch);
        this.propertyValue = propertyValue;
    }

    @Override
    public boolean checkEligibility(double income, int creditScore) {
        return income > 800 && creditScore >= 650;
    }

    @Override
    public double calculateInterest() {
        return super.calculateInterest() * 0.9;
    }

    @Override
    public String generateLoanReport() {
        return super.generateLoanReport() + "\nProperty Value: " + propertyValue;
    }

    @Override
    public String toString() {
        return super.toString() + "\nProperty Value: " + propertyValue;
    }
}
