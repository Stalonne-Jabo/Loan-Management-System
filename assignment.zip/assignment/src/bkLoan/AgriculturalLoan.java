package bkLoan;

public class AgriculturalLoan extends LoanManager {

    private double farmSize;

    public AgriculturalLoan(String loanId, double amount, double rate, int duration,
                            String officer, String branch, double farmSize) {

        super(loanId, "Agricultural", amount, rate, duration, "Pending", officer, branch);
        this.farmSize = farmSize;
    }

    @Override
    public boolean checkEligibility(double income, int creditScore) {
        return farmSize > 2 && creditScore >= 550;
    }

    @Override
    public double calculateInterest() {
        return super.calculateInterest() * 0.85;
    }

    @Override
    public String generateLoanReport() {
        return super.generateLoanReport() + "\nFarm Size: " + farmSize + " hectares";
    }

    @Override
    public String toString() {
        return super.toString() + "\nFarm Size: " + farmSize;
    }


}
