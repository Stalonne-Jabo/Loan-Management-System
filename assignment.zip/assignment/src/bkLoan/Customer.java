package bkLoan;

public class Customer {
    private String customerId;
    private String customerName;
    private String nationalId;
    private String phoneNumber;

    // Default Constructor
    public Customer() {
    }

    // Parameterized Constructor
    public Customer(String customerId, String customerName,
                    String nationalId, String phoneNumber) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.nationalId = nationalId;
        this.phoneNumber = phoneNumber;
    }

    // Getters and Setters
    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getNationalId() {
        return nationalId;
    }

    public void setNationalId(String nationalId) {
        this.nationalId = nationalId;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    // toString Method
    @Override
    public String toString() {
        return "===== CUSTOMER DETAILS =====\n" +
                "Customer ID: " + customerId + "\n" +
                "Name: " + customerName + "\n" +
                "National ID: " + nationalId + "\n" +
                "Phone Number: " + phoneNumber;
    }
}

