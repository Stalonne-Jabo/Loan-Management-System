package bkLoan;

import Payable.payable;

//public class LoanManager {
    public class LoanManager extends Loan implements payable {

        private String officerName;
        private String branchLocation;

        private double remainingBalance;

        public LoanManager() {
            super();
        }

        // Parameterized Constructor
        public LoanManager(String loanId, String loanType, double loanAmount,
                           double interestRate, int loanDuration, String loanStatus,
                           String officerName, String branchLocation) {

            super(loanId, loanType, loanAmount, interestRate, loanDuration, loanStatus);

            this.officerName = officerName;
            this.branchLocation = branchLocation;
            this.remainingBalance = loanAmount;
        }

        public String getOfficerName() {
            return officerName;
        }

        public void setOfficerName(String officerName) {
            this.officerName = officerName;
        }

        public String getBranchLocation() {
            return branchLocation;
        }

        public void setBranchLocation(String branchLocation) {
            this.branchLocation = branchLocation;
        }


        // IMPLEMENT ABSTRACT METHODS

        @Override
        public double calculateInterest() {
            return (getLoanAmount() * getInterestRate() * getLoanDuration()) / 100;
        }

        @Override
        public double calculateMonthlyInstallment() {
            double total = calculateTotalRepayment();
            return total / getLoanDuration();
        }

        @Override
        public boolean checkEligibility(double income, int creditScore) {
            return income > 500 && creditScore >= 600;
        }

        @Override
        public void approveLoan() {
            setLoanStatus("Approved");
        }

        @Override
        public void rejectLoan() {
            setLoanStatus("Rejected");
        }

        @Override
        public double calculateTotalRepayment() {
            return getLoanAmount() + calculateInterest();
        }

        @Override
        public String generateLoanReport() {
            return "===== LOAN REPORT =====\n" +
                    toString() + "\n" +
                    "Officer: " + officerName + "\n" +
                    "Branch: " + branchLocation + "\n" +
                    "Total Repayment: " + calculateTotalRepayment();
        }

        @Override
        public boolean validateLoanDetails() {
            return getLoanAmount() > 0 &&
                    getInterestRate() > 0 &&
                    getLoanDuration() > 0;
        }

        // IMPLEMENT INTERFACE METHODS


        @Override
        public void processPayment(double amount) {
            if (amount > 0 && amount <= remainingBalance) {
                remainingBalance -= amount;
                System.out.println("Payment successful: " + amount);
            } else {
                System.out.println("Invalid payment amount.");
            }
        }

        @Override
        public double calculateRemainingBalance() {
            return remainingBalance;
        }

        @Override
        public String generatePaymentReceipt(double amount) {
            return "----- PAYMENT RECEIPT -----\n" +
                    "Paid Amount: " + amount + "\n" +
                    "Remaining Balance: " + remainingBalance;
        }

        // toString()


        @Override
        public String toString() {
            return super.toString() + "\n" +
                    "Officer Name: " + officerName + "\n" +
                    "Branch Location: " + branchLocation;
        }
}
