package bkLoan;

public class StudentLoan extends LoanManager {

    private String universityName;

    public StudentLoan(String loanId, double amount, double rate, int duration,
                       String officer, String branch, String universityName) {

        super(loanId, "Student", amount, rate, duration, "Pending", officer, branch);
        this.universityName = universityName;
    }

    @Override
    public boolean checkEligibility(double income, int creditScore) {
        return creditScore >= 500;
    }

    @Override
    public double calculateInterest() {
        return super.calculateInterest() * 0.8;
    }

    @Override
    public String generateLoanReport() {
        return super.generateLoanReport() + "\nUniversity: " + universityName;
    }

    @Override
    public String toString() {
        return super.toString() + "\nUniversity: " + universityName;
    }

}
