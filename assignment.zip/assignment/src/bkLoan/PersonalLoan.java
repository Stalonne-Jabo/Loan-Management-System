package bkLoan;

public class PersonalLoan extends LoanManager {

    private String purpose;

    public PersonalLoan(String loanId, double amount, double rate, int duration,
                        String officer, String branch, String purpose) {

        super(loanId, "Personal", amount, rate, duration, "Pending", officer, branch);
        this.purpose = purpose;
    }

    @Override
    public boolean checkEligibility(double income, int creditScore) {
        return income > 300 && creditScore >= 550;
    }

    @Override
    public double calculateInterest() {
        return super.calculateInterest() * 1.05;
    }

    @Override
    public String generateLoanReport() {
        return super.generateLoanReport() + "\nPurpose: " + purpose;
    }

    @Override
    public String toString() {
        return super.toString() + "\nPurpose: " + purpose;
    }
}
