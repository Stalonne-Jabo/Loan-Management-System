package bkLoan;

import java.time.LocalDate;

public class Repayment {
    private int paymentId;
    private Loan loan;
    private double amountPaid;
    private LocalDate paymentDate;
    private double remainingBalance;

    public Repayment() {
    }

    public Repayment(int paymentId, Loan loan, double amountPaid,
                     LocalDate paymentDate, double remainingBalance) {

        this.paymentId = paymentId;
        this.loan = loan;
        this.amountPaid = amountPaid;
        this.paymentDate = paymentDate;
        this.remainingBalance = remainingBalance;
    }

    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public Loan getLoan() {
        return loan;
    }

    public void setLoan(Loan loan) {
        this.loan = loan;
    }

    public double getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(double amountPaid) {
        this.amountPaid = amountPaid;
    }

    public LocalDate getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(LocalDate paymentDate) {
        this.paymentDate = paymentDate;
    }

    public double getRemainingBalance() {
        return remainingBalance;
    }

    public void setRemainingBalance(double remainingBalance) {
        this.remainingBalance = remainingBalance;
    }


    public void updateRemainingBalance(double paymentAmount) {

        if (loan instanceof LoanManager) {
            LoanManager m = (LoanManager) loan;

            double currentBalance = m.calculateRemainingBalance();

            if (paymentAmount > 0 && paymentAmount <= currentBalance) {
                m.processPayment(paymentAmount);
                this.remainingBalance = m.calculateRemainingBalance();
                this.amountPaid = paymentAmount;
                this.paymentDate = LocalDate.now();
            } else {
                System.out.println("Invalid payment amount.");
            }
        } else {
            System.out.println("Loan is not payable.");
        }
    }

    // toString Method
    @Override
    public String toString() {
        return "===== REPAYMENT DETAILS =====\n" +
                "Payment ID: " + paymentId + "\n" +
                "Loan ID: " + (loan != null ? loan.getLoanId() : "N/A") + "\n" +
                "Amount Paid: " + amountPaid + "\n" +
                "Payment Date: " + paymentDate + "\n" +
                "Remaining Balance: " + remainingBalance;
    }

}
