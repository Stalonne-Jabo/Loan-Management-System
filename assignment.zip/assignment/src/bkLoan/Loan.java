package bkLoan;

public abstract class Loan {
    private String loanId;
    private String loanType;
    private double loanAmount;
    private double interestRate;
    private int loanDuration; // in months
    private String loanStatus;

    // Default Constructor
    public Loan() {
    }

    // Parameterized Constructor
    public Loan(String loanId, String loanType, double loanAmount,
                double interestRate, int loanDuration, String loanStatus) {
        this.loanId = loanId;
        this.loanType = loanType;
        this.loanAmount = loanAmount;
        this.interestRate = interestRate;
        this.loanDuration = loanDuration;
        this.loanStatus = loanStatus;
    }

    // Getters and Setters
    public String getLoanId() {
        return loanId;
    }

    public void setLoanId(String loanId) {
        this.loanId = loanId;
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    public double getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public int getLoanDuration() {
        return loanDuration;
    }

    public void setLoanDuration(int loanDuration) {
        this.loanDuration = loanDuration;
    }

    public String getLoanStatus() {
        return loanStatus;
    }

    public void setLoanStatus(String loanStatus) {
        this.loanStatus = loanStatus;
    }

    // toString Method
    @Override
    public String toString() {
        return "Loan Details:\n" +
                "Loan ID: " + loanId + "\n" +
                "Loan Type: " + loanType + "\n" +
                "Loan Amount: " + loanAmount + "\n" +
                "Interest Rate: " + interestRate + "%\n" +
                "Duration: " + loanDuration + " months\n" +
                "Status: " + loanStatus;
    }

    //ABSTRACT METHODS

    public abstract double calculateInterest();

    public abstract double calculateMonthlyInstallment();

    public abstract boolean checkEligibility(double income, int creditScore);

    public abstract void approveLoan();

    public abstract void rejectLoan();

    public abstract double calculateTotalRepayment();

    public abstract String generateLoanReport();

    public abstract boolean validateLoanDetails();
}

