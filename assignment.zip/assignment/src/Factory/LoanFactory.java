package Factory;

import bkLoan.PersonalLoan;
import bkLoan.*;

public class LoanFactory {
    public static LoanManager createLoan(
            String type,
            String loanId,
            double amount,
            double rate,
            int duration,
            String officer,
            String branch
    ) {

        switch (type.toLowerCase()) {

            case "personal":
                return new PersonalLoan(
                        loanId, amount, rate, duration,
                        officer, branch, "General Use"
                );

            case "home":
                return new HomeLoan(
                        loanId, amount, rate, duration,
                        officer, branch, 50000000
                );

            case "car":
                return new CarLoan(
                        loanId, amount, rate, duration,
                        officer, branch, "Toyota"
                );

            case "business":
                return new BusinessLoan(
                        loanId, amount, rate, duration,
                        officer, branch, "MyBusiness Ltd"
                );

            case "student":
                return new StudentLoan(
                        loanId, amount, rate, duration,
                        officer, branch, "AUCA"
                );

            case "agricultural":
                return new AgriculturalLoan(
                        loanId, amount, rate, duration,
                        officer, branch, 3.5
                );

            default:
                throw new IllegalArgumentException("Invalid loan type: " + type);
        }
    }

}
