package Payable;

public interface payable {
    void processPayment(double amount);     // Process a loan payment

    double calculateRemainingBalance();  // Calculate remaining loan balance

    String generatePaymentReceipt(double amount);      // Generate payment receipt

}
