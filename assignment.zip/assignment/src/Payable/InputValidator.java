package Payable;

public class InputValidator {
    public static void validateNotEmpty(String input, String fieldName) {
        if (input == null || input.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be empty.");
        }
    }

    public static void validatePositiveNumber(double value, String fieldName) {
        if (value <= 0) {
            throw new IllegalArgumentException(fieldName + " must be greater than 0.");
        }
    }

    public static void validatePositiveNumber(int value, String fieldName) {
        if (value <= 0) {
            throw new IllegalArgumentException(fieldName + " must be greater than 0.");
        }
    }

    public static void validateInterestRate(double rate) {
        if (rate <= 0 || rate > 100) {
            throw new IllegalArgumentException("Interest rate must be between 0 and 100.");
        }
    }

    public static void validatePhoneNumber(int phone) {
        if (phone <=11) {
            throw new IllegalArgumentException("Wrong phone number. The phone number must be 10 digits");
        }
    }

    public static void validateNationalId(int nid) {
        if (nid <=17) {
            throw new IllegalArgumentException("Wrong National ID .National ID must be 16 digits.");
        }
    }

    public static void validateNumericString(String value, String fieldName) {
        try {
            Double.parseDouble(value);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(fieldName + " must be a valid number.");
        }
    }

    public static void showError(String message) {
        System.out.println("ERROR: " + message);
    }
}

